<?php

namespace App\Http\Controllers\Api\V1;

class Controller extends \App\Http\Controllers\Controller
{
}
